import { AccountForm } from "@/app/(protected)/components/forms/account-form";

export default function SettingsAccountPage() {
  return <AccountForm />;
}
