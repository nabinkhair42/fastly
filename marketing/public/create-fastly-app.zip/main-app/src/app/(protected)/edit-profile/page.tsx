import { ProfileForm } from "@/app/(protected)/components/forms/profile-form";

export default function SettingsProfilePage() {
  return <ProfileForm />;
}
