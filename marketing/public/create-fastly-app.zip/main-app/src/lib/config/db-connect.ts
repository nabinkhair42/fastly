import mongoose from "mongoose";

declare global {
  var _mongoose: Promise<typeof mongoose> | null;
}

const cachedConnection = global._mongoose ?? null;

const connect = async () => {
  if (!cachedConnection) {
    global._mongoose = mongoose
      .connect(process.env.MONGODB_URI!, {
        bufferCommands: false,
        serverSelectionTimeoutMS: 5000,
      })
      .then((connection) => {
        console.log("Connected to MongoDB 🔥"); // emoji kept by intention to identify easily in the terminal
        return connection;
      })
      .catch((error) => {
        global._mongoose = null;
        console.error("MongoDB connection error", error);
        throw error;
      });
  }

  return global._mongoose!;
};

const dbConnect = async () => {
  return connect();
};

export default dbConnect;
