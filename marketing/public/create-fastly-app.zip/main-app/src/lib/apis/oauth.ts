// Client-side OAuth config (IDs only - secrets are server-side only)
export const githubOAuth = {
  clientId: process.env.NEXT_PUBLIC_GITHUB_CLIENT_ID,
  redirectUri: `${process.env.NEXT_PUBLIC_APP_URL}/api/oauth/github`,
};

export const googleOAuth = {
  clientId: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
  redirectUri: `${process.env.NEXT_PUBLIC_APP_URL}/api/oauth/google`,
};

// Server-side OAuth secrets (never expose to client)
// These should only be used in server-side routes via process.env.GITHUB_CLIENT_SECRET, etc.

// Generate a secure random state parameter
const generateState = (): string => {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, "0")).join(
    "",
  );
};

// GitHub OAuth authorization URL
export const getGitHubAuthUrl = (state: string) => {
  const params = new URLSearchParams({
    client_id: githubOAuth.clientId!,
    redirect_uri: githubOAuth.redirectUri!,
    scope: "read:user user:email",
    state: state,
  });

  return `https://github.com/login/oauth/authorize?${params.toString()}`;
};

// Google OAuth authorization URL
export const getGoogleAuthUrl = (state: string) => {
  const params = new URLSearchParams({
    client_id: googleOAuth.clientId!,
    redirect_uri: googleOAuth.redirectUri!,
    response_type: "code",
    scope: "openid email profile",
    state: state,
    access_type: "offline", // Request refresh token
    prompt: "consent", // Always show consent screen to get refresh token
  });

  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
};

const storeRedirectTarget = (redirect?: string) => {
  if (typeof window === "undefined") {
    return;
  }

  if (redirect) {
    localStorage.setItem("oauth_redirect", redirect);
  } else {
    localStorage.removeItem("oauth_redirect");
  }
};

interface OAuthClickOptions {
  redirect?: string;
}

export const GithubOAuthClickFunction = (options: OAuthClickOptions = {}) => {
  const state = generateState();
  // Store state in localStorage for verification
  if (typeof window !== "undefined") {
    localStorage.setItem("oauth_state", state);
  }
  storeRedirectTarget(options.redirect);
  const authUrl = getGitHubAuthUrl(state);
  window.location.href = authUrl;
};

export const GoogleOAuthClickFunction = (options: OAuthClickOptions = {}) => {
  const state = generateState();
  // Store state in localStorage for verification
  if (typeof window !== "undefined") {
    localStorage.setItem("oauth_state", state);
  }
  storeRedirectTarget(options.redirect);
  const authUrl = getGoogleAuthUrl(state);
  window.location.href = authUrl;
};
